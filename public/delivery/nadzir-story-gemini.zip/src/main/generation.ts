import { randomUUID } from 'node:crypto'
import { mkdirSync, writeFileSync } from 'node:fs'
import { dirname } from 'node:path'
import { estimateWordTimings } from '@shared/captions'
import { stripVoiceTags } from '@shared/speech'
import { getImageModel, getVideoModel, imageBody, maxRefs, promptLimit, videoBody, type HfModel } from '@shared/higgsfield'
import {
  getMediaImageModel,
  getMediaVideoModel,
  isGeminiImageModel,
  isGeminiVideoModel,
  mediaEffectiveResolution,
  mediaFitDuration,
  mediaMaxRefs,
  mediaPromptLimit,
  mediaProviderOf,
  type GeminiImageModel,
  type GeminiVideoModel
} from '@shared/media'
import { getStyle } from '@shared/styles'
import type { AspectRatio, Asset, Character, Clip, CreditEstimate, Job, Project, WordTiming } from '@shared/types'
import { getDb } from './db'
import { emit } from './events'
import { runJob, type TaskCtx } from './jobs'
import { assetAbsPath } from './paths'
import {
  activeJobFor,
  charactersOf,
  clipsOf,
  getAsset,
  getCharacter,
  getClip,
  getJob,
  getProject,
  insertAsset,
  insertJob,
  patchClip,
  setCharacterSheet,
  touchProject,
  unfinishedJobs,
  updateAssetMeta,
  updateJob
} from './repo'
import { dropCache, getSettings, readCache, writeCache } from './settings'
import { probeDurationMs, probeSize } from './services/audio'
import * as eleven from './services/elevenlabs'
import * as gemini from './services/gemini'
import * as hf from './services/higgsfield'
import { downloadTo, sleep } from './services/http'

const DAY = 24 * 60 * 60 * 1000

function extFromType(contentType: string, url: string, fallback: string): string {
  if (/png/.test(contentType)) return '.png'
  if (/jpe?g/.test(contentType)) return '.jpg'
  if (/webp/.test(contentType)) return '.webp'
  if (/mp4/.test(contentType)) return '.mp4'
  const m = /\.(png|jpe?g|webp|mp4|mov)(\?|$)/i.exec(url)
  return m ? `.${m[1].toLowerCase()}` : fallback
}

function saveFile(projectId: string, folder: string, ext: string, bytes: Buffer): string {
  const rel = `${folder}/${randomUUID()}${ext}`
  const abs = assetAbsPath(projectId, rel)
  mkdirSync(dirname(abs), { recursive: true })
  writeFileSync(abs, bytes)
  return rel
}

/** A URL Higgsfield can fetch for a stored asset: its own recent result URL, or a fresh upload. */
async function publicUrlFor(asset: Asset, signal: AbortSignal): Promise<string> {
  if (asset.remoteUrl && asset.provider === 'higgsfield' && Date.now() - asset.createdAt < 6 * DAY) return asset.remoteUrl
  const up = asset.meta.uploadedUrl as string | undefined
  const at = asset.meta.uploadedAt as number | undefined
  if (up && at && Date.now() - at < 0.5 * DAY) return up
  const url = await hf.uploadFile(assetAbsPath(asset.projectId, asset.localPath), signal)
  updateAssetMeta(asset.id, { ...asset.meta, uploadedUrl: url, uploadedAt: Date.now() })
  return url
}

function imageProgress(ctx: TaskCtx, what: string) {
  return (status: hf.HfStatus, elapsed: number): void => {
    if (status === 'queued') ctx.progress(0.12, 'Mengantre di Higgsfield')
    else ctx.progress(0.15 + 0.75 * (1 - Math.exp(-elapsed / 45_000)), what)
  }
}

/** Veo reports no percent, so progress follows the same elapsed-time curve as a Higgsfield job. */
function geminiProgress(ctx: TaskCtx, what: string) {
  return (elapsed: number): void => ctx.progress(0.15 + 0.75 * (1 - Math.exp(-elapsed / 45_000)), what)
}

// ---------- prompts ----------

function characterLine(c: Character): string {
  return `${c.name}: ${c.description}`
}

/** Splits the storyboard's "Avoid:" line off the scene, so it can be phrased as a clear instruction. */
function splitAvoid(visual: string): { scene: string; avoid: string } {
  const lines = visual.split('\n')
  const i = lines.findIndex((l) => /^\s*avoid\s*:/i.test(l))
  if (i < 0) return { scene: visual.trim(), avoid: '' }
  const avoid = lines[i].replace(/^\s*avoid\s*:\s*/i, '').replace(/\.$/, '').trim()
  lines.splice(i, 1)
  return { scene: lines.join('\n').trim(), avoid }
}

/**
 * The image prompt for a clip. The scene comes first so the model gets the content right, then who the
 * characters are, then the art style. Clothing follows the scene's Wardrobe line when it has one, so a
 * character can change out of the outfit on their reference sheet (no spacesuit indoors).
 */
function clipPrompt(project: Project, clip: Clip, chars: Character[], refNames: string[], limit: number): string {
  const style = getStyle(project.styleId)
  const { scene, avoid } = splitAvoid(clip.visualPrompt)
  const wardrobe = /^\s*wardrobe\s*:/im.test(scene)
  const parts = [`Scene:\n${scene}`]
  if (chars.length)
    parts.push(
      `Recurring characters in this scene. Keep each one's body, face, hair and skin exactly as described${refNames.length ? ' and as on their reference sheet' : ''}.` +
        (wardrobe
          ? ' Their clothing follows the Wardrobe line of the scene: the default outfit only where it says so, otherwise the custom outfit.'
          : ' They wear their default outfit.') +
        `\n${chars.map(characterLine).join('\n')}`
    )
  if (refNames.length)
    parts.push(
      `Reference images are character sheets, in this order: ${refNames.join(', ')}. Use them for each character's identity, proportions and colors. ` +
        (wardrobe ? 'Copy the costume from a sheet only for characters whose Wardrobe line says "default outfit". ' : 'Match the costume to the sheet. ') +
        'Do not copy the sheet layout, poses or plain background.'
    )
  parts.push(`Art style: ${style.prompt}`)
  if (avoid) parts.push(`Must not appear in the image: ${avoid}.`)
  parts.push(`Frame format ${project.aspectRatio}, full-bleed composition.`)
  const full = parts.join('\n\n')
  if (full.length <= limit) return full
  // Models with short prompt limits get the scene first, so trimming only loses style detail.
  return [scene, chars.map(characterLine).join('; '), avoid && `Must not appear: ${avoid}.`, style.prompt].filter(Boolean).join('\n\n')
}

function sheetPrompt(project: Project, c: Character): string {
  const style = getStyle(project.styleId)
  return [
    style.prompt,
    `Character reference sheet for "${c.name}": ${c.description}. The character is ${style.characterHint}.`,
    'Show the SAME character three times side by side: front view, three-quarter view and side view, full body, neutral standing pose, evenly spaced, on a plain light neutral background (this overrides any background instruction above). Consistent proportions, costume and colors in all three views.'
  ].join('\n\n')
}

// ---------- waiting for character sheets ----------

async function waitForSheets(characterIds: string[], signal: AbortSignal): Promise<void> {
  const started = Date.now()
  while (Date.now() - started < 15 * 60 * 1000) {
    const pending = characterIds.some((id) => activeJobFor({ characterId: id }, 'sheet'))
    if (!pending) return
    await sleep(2000, signal)
  }
}

async function referenceUrls(model: HfModel, chars: Character[], signal: AbortSignal): Promise<{ urls: string[]; names: string[] }> {
  const limit = maxRefs(model)
  if (limit === 0) return { urls: [], names: [] }
  await waitForSheets(
    chars.map((c) => c.id),
    signal
  )
  const urls: string[] = []
  const names: string[] = []
  for (const c of chars) {
    const fresh = getCharacter(c.id)
    const sheet = getAsset(fresh.sheetAssetId)
    if (!sheet || urls.length >= limit) continue
    urls.push(await publicUrlFor(sheet, signal))
    names.push(fresh.name)
  }
  return { urls, names }
}

/**
 * The video prompt for a clip: the storyboard's direction, or a gentle move when there is none. Shared by
 * every provider so a switch of model never changes what a clip shows.
 */
function clipVideoPrompt(clip: Clip): string {
  return (
    clip.videoPrompt.trim() ||
    `${splitAvoid(clip.visualPrompt).scene.replace(/\.$/, '')}. Subtle natural motion of the characters and environment, the camera slowly pushes in. Keep the art style of the first frame.`
  )
}

// ---------- finishing a generation, Higgsfield or Gemini (also used to resume after a restart) ----------

interface MediaPayload {
  target: 'clip-image' | 'sheet' | 'clip-video'
  model: string
  prompt: string
}

interface SavedMedia {
  target: MediaPayload['target']
  provider: string
  model: string
  prompt: string
  kind: 'image' | 'video'
  bytes: Buffer
  contentType: string
  /** Public result URL, when the provider keeps one (Higgsfield does; Gemini file links expire fast). */
  url: string | null
  remoteId: string | null
}

/** Everything after the bytes are in: probe, save, link to clip or character sheet, touch the project. */
async function saveGenerated(ctx: TaskCtx, job: Job, saved: SavedMedia): Promise<string> {
  const isVideo = saved.kind === 'video'
  ctx.progress(0.93, 'Menyimpan hasil')
  const rel = saveFile(job.projectId, isVideo ? 'videos' : 'images', extFromType(saved.contentType, saved.url ?? '', isVideo ? '.mp4' : '.png'), saved.bytes)
  const abs = assetAbsPath(job.projectId, rel)
  const size = await probeSize(abs)
  const durationMs = isVideo ? await probeDurationMs(abs).catch(() => null) : null
  const asset = insertAsset({
    projectId: job.projectId,
    clipId: job.clipId,
    characterId: job.characterId,
    kind: isVideo ? 'video' : 'image',
    provider: saved.provider,
    model: saved.model,
    prompt: saved.prompt,
    remoteId: saved.remoteId,
    remoteUrl: saved.url,
    localPath: rel,
    durationMs,
    width: size?.width ?? null,
    height: size?.height ?? null
  })
  emit.asset(asset)
  if (saved.target === 'sheet' && job.characterId) {
    setCharacterSheet(job.characterId, asset.id)
    emit.character({ characterId: job.characterId, patch: { sheetAssetId: asset.id } })
  } else if (saved.target === 'clip-image' && job.clipId) {
    patchClip(job.clipId, { imageAssetId: asset.id })
    emit.clip({ clipId: job.clipId, patch: { imageAssetId: asset.id } })
    const project = getProject(job.projectId)
    const first = clipsOf(job.projectId)[0]
    if (!project.coverAssetId || first?.id === job.clipId) touchProject(job.projectId, { coverAssetId: asset.id })
  } else if (saved.target === 'clip-video' && job.clipId) {
    const patch = { videoAssetId: asset.id, motionType: 'video' as const, mediaInMs: 0 }
    patchClip(job.clipId, patch)
    emit.clip({ clipId: job.clipId, patch })
  }
  touchProject(job.projectId)
  return asset.id
}

async function finishHiggsfield(ctx: TaskCtx, job: Job, requestId: string, payload: MediaPayload): Promise<string> {
  const isVideo = payload.target === 'clip-video'
  const result = await hf.waitForResult(
    requestId,
    imageProgress(ctx, isVideo ? 'Membuat video' : payload.target === 'sheet' ? 'Membuat lembar karakter' : 'Membuat gambar'),
    ctx.signal,
    isVideo ? 30 * 60 * 1000 : 15 * 60 * 1000
  )
  const url = isVideo ? result.video?.url : result.images?.[0]?.url
  if (!url) throw new Error('Higgsfield selesai tanpa file hasil')
  ctx.progress(0.93, 'Mengunduh hasil')
  const { bytes, contentType } = await downloadTo(url, ctx.signal)
  return saveGenerated(ctx, job, {
    target: payload.target,
    provider: 'higgsfield',
    model: payload.model,
    prompt: payload.prompt,
    kind: isVideo ? 'video' : 'image',
    bytes,
    contentType,
    url,
    remoteId: requestId
  })
}

// ---------- Gemini (Nano Banana images, Veo videos) ----------

/**
 * Character sheets as inline images. Gemini takes files directly, so unlike Higgsfield there is no upload:
 * the local sheet is read back and sent as base64.
 */
async function inlineSheets(model: GeminiImageModel, chars: Character[], signal: AbortSignal): Promise<{ names: string[]; refs: gemini.InlineImage[] }> {
  if (!model.refs) return { names: [], refs: [] }
  await waitForSheets(
    chars.map((c) => c.id),
    signal
  )
  const names: string[] = []
  const refs: gemini.InlineImage[] = []
  for (const c of chars) {
    const fresh = getCharacter(c.id)
    const sheet = getAsset(fresh.sheetAssetId)
    if (!sheet || refs.length >= model.refs) continue
    refs.push(await gemini.readInline(assetAbsPath(sheet.projectId, sheet.localPath)))
    names.push(fresh.name)
  }
  return { names, refs }
}

function startGeminiImage(
  job: Job,
  model: GeminiImageModel,
  build: (ctx: TaskCtx) => Promise<{ prompt: string; aspect: AspectRatio; refs: gemini.InlineImage[]; size: string | null; target: MediaPayload['target'] }>
): Job {
  emit.job(job)
  return runJob(job, 'gemini', async (ctx) => {
    ctx.progress(0.04, 'Menyiapkan prompt')
    const { prompt, aspect, refs, size, target } = await build(ctx)
    ctx.progress(0.1, 'Mengirim ke Gemini')
    const out = await gemini.generateImage(model, prompt, aspect, refs, size, ctx.signal)
    return saveGenerated(ctx, job, {
      target,
      provider: 'gemini',
      model: model.id,
      prompt,
      kind: 'image',
      bytes: out.bytes,
      contentType: out.mimeType,
      url: null,
      remoteId: null
    })
  })
}

function startGeminiVideo(job: Job, model: GeminiVideoModel, build: (ctx: TaskCtx) => Promise<{ prompt: string; image: gemini.InlineImage; aspect: AspectRatio; resolution: string | null; durationSeconds: number }>): Job {
  emit.job(job)
  return runJob(job, 'gemini', async (ctx) => {
    ctx.progress(0.04, 'Menyiapkan gambar awal')
    const { prompt, image, aspect, resolution, durationSeconds } = await build(ctx)
    ctx.progress(0.08, 'Mengirim ke Gemini')
    const operation = await gemini.startVideo(model, { prompt, image, aspect, resolution, durationSeconds }, ctx.signal)
    ctx.setRemote(operation)
    updateJobPayload(job.id, { target: 'clip-video', model: model.id, prompt })
    const out = await gemini.waitVideo(operation, geminiProgress(ctx, 'Membuat video'), ctx.signal, 30 * 60 * 1000)
    return saveGenerated(ctx, job, {
      target: 'clip-video',
      provider: 'gemini',
      model: model.id,
      prompt,
      kind: 'video',
      bytes: out.bytes,
      contentType: out.mimeType,
      url: null,
      remoteId: operation
    })
  })
}

function startHiggsfield(job: Job, build: (ctx: TaskCtx) => Promise<{ endpoint: string; body: Record<string, unknown>; payload: MediaPayload }>): Job {
  emit.job(job)
  return runJob(job, 'higgsfield', async (ctx) => {
    ctx.progress(0.04, 'Menyiapkan prompt')
    const { endpoint, body, payload } = await build(ctx)
    ctx.progress(0.08, 'Mengirim ke Higgsfield')
    const requestId = await hf.submit(endpoint, body, ctx.signal)
    ctx.setRemote(requestId)
    updateJobPayload(job.id, payload)
    return finishHiggsfield(ctx, job, requestId, payload)
  })
}

function updateJobPayload(jobId: string, payload: MediaPayload): void {
  getDb().prepare('UPDATE jobs SET payload_json = ? WHERE id = ?').run(JSON.stringify(payload), jobId)
}

// ---------- public entry points ----------

export function generateClipImage(clipId: string): Job {
  const existing = activeJobFor({ clipId }, 'image')
  if (existing) return existing
  const clip = getClip(clipId)
  const model = getMediaImageModel(getProject(clip.projectId).imageModel)
  const job = insertJob({ projectId: clip.projectId, clipId, kind: 'image', provider: mediaProviderOf(model.id) })
  if (isGeminiImageModel(model)) {
    return startGeminiImage(job, model, async (ctx) => {
      const fresh = getClip(clipId)
      const project = getProject(fresh.projectId)
      const chars = charactersOf(project.id).filter((c) => fresh.characterIds.includes(c.id))
      const { names, refs } = await inlineSheets(model, chars, ctx.signal)
      const prompt = clipPrompt(project, fresh, chars, names, mediaPromptLimit(model))
      return { prompt, aspect: project.aspectRatio, refs, size: mediaEffectiveResolution(model), target: 'clip-image' }
    })
  }
  return startHiggsfield(job, async (ctx) => {
    const fresh = getClip(clipId)
    const project = getProject(fresh.projectId)
    const hfModel = model as HfModel
    const chars = charactersOf(project.id).filter((c) => fresh.characterIds.includes(c.id))
    const refs = await referenceUrls(hfModel, chars, ctx.signal)
    const prompt = clipPrompt(project, fresh, chars, refs.names, promptLimit(hfModel))
    return {
      endpoint: hfModel.id,
      body: imageBody(hfModel, prompt, project.aspectRatio, refs.urls),
      payload: { target: 'clip-image', model: hfModel.id, prompt }
    }
  })
}

export function generateCharacterSheet(characterId: string): Job {
  const existing = activeJobFor({ characterId }, 'sheet')
  if (existing) return existing
  const c = getCharacter(characterId)
  const model = getMediaImageModel(getProject(c.projectId).imageModel)
  const job = insertJob({ projectId: c.projectId, characterId, kind: 'sheet', provider: mediaProviderOf(model.id) })
  if (isGeminiImageModel(model)) {
    return startGeminiImage(job, model, async () => {
      const project = getProject(c.projectId)
      const prompt = sheetPrompt(project, getCharacter(characterId))
      return { prompt, aspect: '16:9', refs: [], size: mediaEffectiveResolution(model), target: 'sheet' }
    })
  }
  return startHiggsfield(job, async () => {
    const project = getProject(c.projectId)
    const hfModel = model as HfModel
    const prompt = sheetPrompt(project, getCharacter(characterId))
    return {
      endpoint: hfModel.id,
      body: imageBody(hfModel, prompt, '16:9', []),
      payload: { target: 'sheet', model: hfModel.id, prompt }
    }
  })
}

export function generateClipVideo(clipId: string): Job {
  const existing = activeJobFor({ clipId }, 'video')
  if (existing) return existing
  const clip = getClip(clipId)
  if (!clip.imageAssetId) throw new Error('Buat gambar klip ini dulu sebelum membuat video AI.')
  const model = getMediaVideoModel(getProject(clip.projectId).videoModel)
  const job = insertJob({ projectId: clip.projectId, clipId, kind: 'video', provider: mediaProviderOf(model.id) })
  if (isGeminiVideoModel(model)) {
    return startGeminiVideo(job, model, async () => {
      const fresh = getClip(clipId)
      const image = getAsset(fresh.imageAssetId)
      if (!image) throw new Error('Gambar klip tidak ditemukan')
      const project = getProject(fresh.projectId)
      return {
        prompt: clipVideoPrompt(fresh),
        image: await gemini.readInline(assetAbsPath(image.projectId, image.localPath)),
        aspect: project.aspectRatio,
        resolution: mediaEffectiveResolution(model, project.videoResolution),
        durationSeconds: mediaFitDuration(model, fresh.durationMs / 1000) ?? 6
      }
    })
  }
  return startHiggsfield(job, async (ctx) => {
    const hfModel = model as HfModel
    const fresh = getClip(clipId)
    const image = getAsset(fresh.imageAssetId)
    if (!image) throw new Error('Gambar klip tidak ditemukan')
    const project = getProject(fresh.projectId)
    ctx.progress(0.05, 'Menyiapkan gambar awal')
    const url = await publicUrlFor(image, ctx.signal)
    let prompt = clipVideoPrompt(fresh)
    if (hfModel.input.mode === 'reference')
      prompt = `Open on the exact scene of the reference image and keep its art style, characters and composition. ${prompt}`
    return {
      endpoint: hfModel.id,
      body: videoBody(hfModel, prompt, url, fresh.durationMs / 1000, project.aspectRatio, project.videoResolution),
      payload: { target: 'clip-video', model: hfModel.id, prompt }
    }
  })
}

export function generateClipTts(clipId: string): Job {
  const existing = activeJobFor({ clipId }, 'tts')
  if (existing) return existing
  const clip = getClip(clipId)
  const project = getProject(clip.projectId)
  const job = insertJob({ projectId: clip.projectId, clipId, kind: 'tts', provider: project.ttsProvider })
  emit.job(job)
  return runJob(job, 'tts', async (ctx) => {
    const fresh = getClip(clipId)
    const p = getProject(fresh.projectId)
    const text = fresh.narration.trim()
    if (!text) throw new Error('Naskah klip ini masih kosong')
    ctx.progress(0.2, 'Membuat suara')
    let rel: string
    let words: WordTiming[] | undefined
    let estimated = false
    const voice = p.ttsVoice || (p.ttsProvider === 'gemini' ? 'Charon' : '')
    if (p.ttsProvider === 'elevenlabs') {
      if (!voice) throw new Error('Pilih suara ElevenLabs dulu di langkah Ide cerita.')
      const out = await eleven.speak(text, voice, p.language, ctx.signal)
      rel = saveFile(p.id, 'audio', '.mp3', out.audio)
      words = out.words
    } else {
      const wav = await gemini.speak(text, voice, p.language, ctx.signal)
      rel = saveFile(p.id, 'audio', '.wav', wav)
    }
    ctx.progress(0.85, 'Mengukur durasi')
    const audioMs = await probeDurationMs(assetAbsPath(p.id, rel))
    if (!words?.length) {
      words = estimateWordTimings(stripVoiceTags(text), audioMs / 1000)
      estimated = true
    }
    const asset = insertAsset({
      projectId: p.id,
      clipId,
      kind: 'audio',
      provider: p.ttsProvider,
      model: p.ttsProvider === 'gemini' ? getSettings().geminiTtsModel : getSettings().elevenModel,
      prompt: text,
      localPath: rel,
      durationMs: audioMs,
      meta: { words, estimatedTimings: estimated, voice }
    })
    emit.asset(asset)
    const durationMs = Math.max(1500, audioMs + 400)
    const patch = { audioAssetId: asset.id, durationMs, voiceInMs: 0, voiceOutMs: null, voiceStartMs: 0 }
    patchClip(clipId, patch)
    emit.clip({ clipId, patch })
    touchProject(p.id)
    return asset.id
  })
}

export function generateMissingImages(projectId: string): Job[] {
  const jobs: Job[] = []
  const project = getProject(projectId)
  const model = getMediaImageModel(project.imageModel)
  if (mediaMaxRefs(model) > 0) {
    const needed = new Set(clipsOf(projectId).flatMap((c) => c.characterIds))
    for (const c of charactersOf(projectId)) {
      if (needed.has(c.id) && !c.sheetAssetId) jobs.push(generateCharacterSheet(c.id))
    }
  }
  for (const clip of clipsOf(projectId)) {
    if (!clip.imageAssetId) jobs.push(generateClipImage(clip.id))
  }
  return jobs
}

/** Turns every clip that has an image but no AI video yet into a video. */
export function generateMissingVideos(projectId: string): Job[] {
  const clips = clipsOf(projectId)
  if (clips.some((c) => !c.imageAssetId)) throw new Error('Buat gambar semua klip dulu sebelum menjadikannya video.')
  return clips.filter((c) => !c.videoAssetId).map((c) => generateClipVideo(c.id))
}

export function generateMissingTts(projectId: string): Job[] {
  return clipsOf(projectId)
    .filter((c) => !c.audioAssetId && c.narration.trim())
    .map((c) => generateClipTts(c.id))
}

/** After a restart, keep polling requests that were already submitted; fail the rest. */
export function resumeJobs(): void {
  for (const row of unfinishedJobs()) {
    const payload = JSON.parse(row.payload_json || '{}') as Partial<MediaPayload>
    if (row.provider === 'higgsfield' && row.remote_id && payload.target) {
      const job = getJob(row.id)!
      runJob(job, 'higgsfield', (ctx) => finishHiggsfield(ctx, job, row.remote_id, payload as MediaPayload))
    } else if (row.provider === 'gemini' && row.remote_id && payload.target === 'clip-video') {
      // Veo images finish inside one request, so only videos have an operation worth resuming.
      const job = getJob(row.id)!
      runJob(job, 'gemini', (ctx) => resumeGeminiVideo(ctx, job, row.remote_id, payload as MediaPayload))
    } else {
      emit.job(updateJob(row.id, { status: 'failed', error: 'Terhenti karena aplikasi ditutup. Coba lagi.', message: null }))
    }
  }
}

async function resumeGeminiVideo(ctx: TaskCtx, job: Job, operation: string, payload: MediaPayload): Promise<string> {
  const out = await gemini.waitVideo(operation, geminiProgress(ctx, 'Membuat video'), ctx.signal, 30 * 60 * 1000)
  return saveGenerated(ctx, job, {
    target: 'clip-video',
    provider: 'gemini',
    model: payload.model,
    prompt: payload.prompt,
    kind: 'video',
    bytes: out.bytes,
    contentType: out.mimeType,
    url: null,
    remoteId: operation
  })
}

export async function setActiveAsset(clipId: string, assetId: string): Promise<void> {
  const asset = getAsset(assetId)
  if (!asset || asset.clipId !== clipId) throw new Error('Aset tidak cocok dengan klip ini')
  const patch: Partial<Clip> =
    asset.kind === 'image'
      ? { imageAssetId: asset.id }
      : asset.kind === 'video'
        ? { videoAssetId: asset.id, mediaInMs: 0 }
        : asset.kind === 'audio'
          ? { audioAssetId: asset.id, durationMs: Math.max(1500, (asset.durationMs ?? 0) + 400), voiceInMs: 0, voiceOutMs: null, voiceStartMs: 0 }
          : {}
  patchClip(clipId, patch)
  emit.clip({ clipId, patch })
}

/** Estimates that failed recently (no key, or a model the account cannot use), so pickers do not keep asking. */
const failedEstimates = new Map<string, number>()

/**
 * Credits for one image, or one clip video of about `seconds`. The model pickers ask for every model,
 * so answers are kept for a day and failures for ten minutes.
 */
export async function estimateCredits(
  kind: 'image' | 'video',
  modelId: string,
  aspect: AspectRatio,
  seconds = 5,
  resolution?: string | null
): Promise<CreditEstimate | null> {
  // Gemini charges per use and publishes no estimate endpoint; its pickers show the model's known pricing instead.
  if (mediaProviderOf(modelId) === 'gemini') return null
  const model = kind === 'image' ? getImageModel(modelId) : getVideoModel(modelId)
  const body =
    kind === 'image'
      ? imageBody(model, 'estimate', aspect, [])
      : videoBody(model, 'estimate', 'https://example.com/frame.png', seconds, aspect, resolution)
  const key = `estimate:${model.id}:${JSON.stringify(body)}`
  const hit = readCache<CreditEstimate>(key)
  if (hit && Date.now() - hit.updatedAt < DAY) return hit.value
  const failedAt = failedEstimates.get(key)
  if (failedAt && Date.now() - failedAt < 10 * 60 * 1000) return null
  const value = await hf.estimate(model.id, body)
  if (value) writeCache(key, value)
  else failedEstimates.set(key, Date.now())
  return value
}

/** Prices can differ per account, so a new Higgsfield key starts from fresh estimates. */
export function forgetEstimates(): void {
  failedEstimates.clear()
  dropCache('estimate:')
}
